import os

def print_banner_black():
    print("\033[92m" + r"""
 _   _ _       _     _    __       _ _ 
| \ | (_) __ _| |__ | |_ / _| __ _| | |
|  \| | |/ _` | '_ \| __| |_ / _` | | |
| |\  | | (_| | | | | |_|  _| (_| | | |
|_| \_|_|\__, |_| |_|\__|_|  \__,_|_|_|
         |___/                         
""" + "\033[0m")
    print("""type 'custom' for custom commands\n""")

def print_banner_white():
    print("\033[38;2;255;165;0m" + r"""
 ____                   _          
/ ___| _   _ _ __  _ __(_)___  ___ 
\___ \| | | | '_ \| '__| / __|/ _ \
 ___) | |_| | | | | |  | \__ \  __/
|____/ \__,_|_| |_|_|  |_|___/\___|
""" + "\033[0m")
    print("""type 'custom' for custom commands\n""")


def sunrise():
    os.system("clear")
    print("\033]11;#000000\007", end="")
    print("\033[97m", end="")
    print_banner_white()


def nightfall():
    print("\033]11;#000000\007", end="")
    print("\033[97m", end="")
    os.system("clear")
    print_banner_black()