#!/usr/bin/env python3
import os
import subprocess
import requests
import shlex
from bs4 import BeautifulSoup
import re
from banners import print_banner_black, print_banner_white, sunrise, nightfall

NIGHTFALL_PATH = os.path.abspath(__file__)
ZSHRC_PATH = os.path.expanduser("~/.zshrc")

print("\033]11;#000000\007", end="")
print("\033[97m", end="")

def ilove_nightfall():
    marker_start = "# NIGHTFALL_START"
    marker_end = "# NIGHTFALL_END"

    with open(ZSHRC_PATH, "r") as file:
        content = file.read()

    if marker_start in content:
        print("[!] Nightfall is already enabled.")
        return

    nightfall_line = f'python3 "{NIGHTFALL_PATH}"'

    with open(ZSHRC_PATH, "a") as file:
        file.write(
            f"\n{marker_start}\n"
            f"{nightfall_line}\n"
            f"{marker_end}\n"
        )

    print("Nightfall is now your default terminal, cool!")


def ihate_nightfall():
    marker_start = "# NIGHTFALL_START"
    marker_end = "# NIGHTFALL_END"

    with open(ZSHRC_PATH, "r") as file:
        content = file.read()

    if marker_start not in content:
        print("Nightfall is already off")
        return

    start = content.index(marker_start)
    end = content.index(marker_end) + len(marker_end)

    new_content = content[:start] + content[end:]

    with open(ZSHRC_PATH, "w") as file:
        file.write(new_content)

    print("I guess I wasn't good enough.")


def dir_search(url):
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    url = url.rstrip("/")

    common_paths = [
        "admin", "administrator", "login", "dashboard", "robots.txt",
        "sitemap.xml", "api", "backup", "config", "test", ".git",
        "uploads", "wp-login.php", "wp-admin", "server-status", "index.php"
    ]

    print(f"\n Scanning directories for: {url}\n")
    headers = {"User-Agent": "Nightfall/4.0"}

    baseline_text = ""
    try:
        base_test = requests.get(f"{url}/randompath987654321", headers=headers, timeout=3, allow_redirects=True)
        if base_test.status_code == 200:
            baseline_text = base_test.text
    except:
        pass

    for path in common_paths:
        target = f"{url}/{path}"
        try:
            response = requests.get(
                target,
                headers=headers,
                timeout=3,
                allow_redirects=True
            )
            status = response.status_code

            if status == 200:
                
                if baseline_text and response.text == baseline_text:
                    continue
                print(f"[+] Found (200): {target}")
            elif status in [301, 302]:
                redirect_loc = response.headers.get("Location")
                print(f"[~] Redirect ({status}): {target} -> {redirect_loc}")
            elif status == 403:
                print(f"[-] Forbidden (403): {target}")
        except requests.RequestException:
            pass

def custom():
    print("""             findip [IP]

             person [First Last]

             place [Name]

             myip [-loc (local) -pub (public) -all (all)]

             pingsite [Website]

             webscan [Website]

             system

             VPN

             ilovenightfall
             
             ihatenightfall
             """)

def pingsite(web):

    try:
        response = requests.get(web, timeout=5)

        if response.status_code < 500:
            print(web + " is alive")
        else:
            print(web + " is dead")

    except requests.RequestException:
        print(web + " could not be reached")


    
def person_search(name):
    WIKIDATA_URL = "https://www.wikidata.org/w/api.php"

    HEADERS = {
        "User-Agent": "Nightfall/4.0"
    }

    properties = {
        "P19": "Birth Place",
        "P569": "Birth Date",
        "P27": "Citizenship",
        "P106": "Occupation",
        "P108": "Employer",
        "P1416": "Affiliation",
        "P463": "Member of",
        "P69": "Education"
    }

    socials = {
        "P2003": "Instagram",
        "P2002": "X",
        "P7085": "TikTok"
    }

    def api_request(url, params):
        try:
            response = requests.get(
                url,
                params=params,
                headers=HEADERS,
                timeout=10
            )

            if response.status_code != 200:
                return None

            return response.json()

        except:
            return None

    def format_date(value):
        if not isinstance(value, dict):
            return value

        time = value.get("time", "")

        if not time:
            return None

        time = time.lstrip("+").split("T")[0]
        parts = time.split("-")

        if len(parts) < 3:
            return time

        months = [
            "",
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"
        ]

        try:
            return f"{months[int(parts[1])]} {int(parts[2])}, {parts[0]}"
        except:
            return parts[0]

    def resolve_entity(entity_id):
        if not entity_id:
            return None

        if not entity_id.startswith("Q"):
            return entity_id

        data = api_request(
            WIKIDATA_URL,
            {
                "action": "wbgetentities",
                "ids": entity_id,
                "props": "labels",
                "languages": "en",
                "format": "json"
            }
        )

        if not data:
            return None

        entity = data.get(
            "entities",
            {}
        ).get(
            entity_id,
            {}
        )

        return (
            entity
            .get("labels", {})
            .get("en", {})
            .get("value")
        )

    def extract_values(claims, property_id):
        values = []

        for claim in claims.get(property_id, []):
            try:
                value = claim["mainsnak"]["datavalue"]["value"]

                if isinstance(value, dict):

                    if "id" in value:
                        value = resolve_entity(value["id"])

                    elif "time" in value:
                        value = format_date(value)

                    elif "amount" in value:
                        value = value["amount"]

                    else:
                        continue

                if value and value not in values:
                    values.append(str(value))

            except:
                continue

        return values

    def wikidata_search():
        data = api_request(
            WIKIDATA_URL,
            {
                "action": "wbsearchentities",
                "search": name,
                "language": "en",
                "format": "json",
                "limit": 10
            }
        )

        if not data:
            return None

        results = data.get("search", [])

        if not results:
            return None

        search_name = name.lower().strip()

        exact = [
            result
            for result in results
            if result.get(
                "label",
                ""
            ).lower().strip() == search_name
        ]

        best = exact[0] if exact else results[0]

        entity_id = best.get("id")

        if not entity_id:
            return None

        entity_data = api_request(
            WIKIDATA_URL,
            {
                "action": "wbgetentities",
                "ids": entity_id,
                "format": "json"
            }
        )

        if not entity_data:
            return None

        entity = entity_data.get(
            "entities",
            {}
        ).get(
            entity_id,
            {}
        )

        claims = entity.get("claims", {})

        info = {
            "Name": best.get(
                "label",
                name
            ),
            "Description": best.get(
                "description",
                ""
            )
        }

        for property_id, property_name in properties.items():

            values = extract_values(
                claims,
                property_id
            )

            if values:
                info[property_name] = ", ".join(
                    values[:3]
                )

        for property_id, platform in socials.items():

            values = extract_values(
                claims,
                property_id
            )

            if values:
                username = values[0]

                if not username.startswith("@"):
                    username = "@" + username

                info[platform] = username

        if len(info) <= 2:
            return None

        return info

    def wikipedia_search():
        data = api_request(
            "https://en.wikipedia.org/w/api.php",
            {
                "action": "query",
                "list": "search",
                "srsearch": f'"{name}"',
                "format": "json",
                "srlimit": 10
            }
        )

        if not data:
            return None

        results = data.get(
            "query",
            {}
        ).get(
            "search",
            []
        )

        if not results:
            return None

        search_name = name.lower().strip()
        scored = []

        for result in results:

            title = result.get(
                "title",
                ""
            )

            title_lower = title.lower()
            score = 0

            if title_lower == search_name:
                score += 100

            elif search_name in title_lower:
                score += 75

            else:
                for word in search_name.split():

                    if word in title_lower:
                        score += 20

            snippet = BeautifulSoup(
                result.get("snippet", ""),
                "html.parser"
            ).get_text(
                " ",
                strip=True
            )

            if search_name in snippet.lower():
                score += 25

            scored.append(
                (score, result, snippet)
            )

        scored.sort(
            key=lambda x: x[0],
            reverse=True
        )

        score, best, snippet = scored[0]

        if score < 75:
            return None

        return {
            "Name": best.get(
                "title",
                name
            ),
            "Description": snippet
        }

    def clean_domain(url):

        if not url:
            return ""

        url = url.replace(
            "https://",
            ""
        ).replace(
            "http://",
            ""
        )

        return url.split("/")[0].lower()

    def web_search():

        try:
            response = requests.get(
                "https://html.duckduckgo.com/html/",
                params={
                    "q": f'"{name}"'
                },
                headers=HEADERS,
                timeout=10
            )

            if response.status_code != 200:
                return None

            soup = BeautifulSoup(
                response.text,
                "html.parser"
            )

            results = []

            blocked_domains = [
                "facebook.com",
                "zoominfo.com",
                "spokeo.com",
                "whitepages.com",
                "beenverified.com",
                "truthfinder.com",
                "fastpeoplesearch.com"
            ]

            blocked_words = [
                "salary",
                "compensation",
                "phone number",
                "email address",
                "contact information",
                "people search"
            ]

            professional_words = [
                "vice-principal",
                "vice principal",
                "principal",
                "teacher",
                "professor",
                "director",
                "coach",
                "doctor",
                "engineer",
                "manager"
            ]

            for result in soup.select(".result"):

                title_element = result.select_one(
                    ".result__a"
                )

                snippet_element = result.select_one(
                    ".result__snippet"
                )

                url_element = result.select_one(
                    ".result__url"
                )

                if not title_element:
                    continue

                title = title_element.get_text(
                    " ",
                    strip=True
                )

                snippet = ""

                if snippet_element:
                    snippet = snippet_element.get_text(
                        " ",
                        strip=True
                    )

                url = ""

                if url_element:
                    url = url_element.get_text(
                        " ",
                        strip=True
                    )

                domain = clean_domain(url)

                text = (
                    title + " " + snippet
                ).lower()

                if any(
                    blocked in domain
                    for blocked in blocked_domains
                ):
                    continue

                if any(
                    word in text
                    for word in blocked_words
                ):
                    continue

                score = 0

                search_name = name.lower()

                if search_name in title.lower():
                    score += 100

                if search_name in snippet.lower():
                    score += 40

                if any(
                    word in text
                    for word in professional_words
                ):
                    score += 30

                if (
                    ".edu" in domain
                    or ".ca" in domain
                    or ".gov" in domain
                    or ".org" in domain
                ):
                    score += 20

                if score < 50:
                    continue

                results.append({
                    "title": title,
                    "snippet": snippet,
                    "domain": domain,
                    "score": score
                })

            results.sort(
                key=lambda x: x["score"],
                reverse=True
            )

            return results[:8]

        except:
            return None

    def extract_web_facts(results):

        facts = {}

        for result in results:

            title = result["title"]
            snippet = result["snippet"]

            text = title + " " + snippet
            lower = text.lower()

            if (
                "vice-principal" in lower
                or "vice principal" in lower
            ):
                facts["Occupation"] = "Vice-Principal"

            elif "principal" in lower:
                facts["Occupation"] = "Principal"

            elif "teacher" in lower:
                facts["Occupation"] = "Teacher"

            elif "professor" in lower:
                facts["Occupation"] = "Professor"

            elif "coach" in lower:
                facts["Occupation"] = "Coach"

            school_patterns = [
                r"(?:at|of|-\s*)([A-Z][A-Za-z0-9&'.\- ]+(?:Secondary School|High School|Public School|Catholic School|School))",
                r"([A-Z][A-Za-z0-9&'.\- ]+Secondary School)",
                r"([A-Z][A-Za-z0-9&'.\- ]+High School)"
            ]

            for pattern in school_patterns:

                match = re.search(
                    pattern,
                    text
                )

                if match:

                    school = match.group(1).strip()

                    school = re.split(
                        r"\s+(?:Joined|is|was|works|located|where)\b",
                        school,
                        flags=re.IGNORECASE
                    )[0].strip()

                    school = re.sub(
                        r"^(?:Vice-Principal|Principal)\s*-\s*",
                        "",
                        school,
                        flags=re.IGNORECASE
                    )

                    if (
                        len(school) < 100
                        and "Vice-Principal" not in school
                        and "Principal" not in school
                    ):
                        facts["School"] = school
                        break

            board_patterns = [
                r"([A-Z][A-Za-z0-9&'.\- ]*?Catholic District School Board)",
                r"([A-Z][A-Za-z0-9&'.\- ]*?District School Board)"
            ]

            for pattern in board_patterns:

                match = re.search(
                    pattern,
                    text
                )

                if match:

                    employer = match.group(1).strip()

                    facts["Employer"] = employer
                    break

            if (
                "x.com" in result["domain"]
                or "twitter.com" in result["domain"]
            ):

                match = re.search(
                    r"@([A-Za-z0-9_]+)",
                    text
                )

                if match:

                    facts["X"] = "@" + match.group(1)

        return facts

    print(
        f"\n[>] Searching: {name}"
    )

    result = wikidata_search()

    if result:

        print(
            f"\n[+] {result.get('Name', name)}\n"
        )

        if result.get("Description"):

            print(
                f"Description: {result['Description']}"
            )

        for key, value in result.items():

            if key in [
                "Name",
                "Description"
            ]:
                continue

            print(
                f"{key}: {value}"
            )

        return

    result = wikipedia_search()

    if result:

        print(
            f"\n[+] {result.get('Name', name)}\n"
        )

        if result.get("Description"):

            print(
                f"Description: {result['Description']}"
            )

        return

    results = web_search()

    if results:

        facts = extract_web_facts(results)

        if facts:

            print(
                f"\n[+] {name.title()}\n"
            )

            for key, value in facts.items():

                print(
                    f"{key}: {value}"
                )

            return

    print(
        "\n[!] No useful public information found."
    )

def place_search(place):
    url = "https://nominatim.openstreetmap.org/search"

    headers = {
        "User-Agent": "Nightfall/4.0"
    }

    params = {
        "q": place,
        "format": "json",
        "addressdetails": 1,
        "limit": 5
    }

    try:
        response = requests.get(
            url,
            params=params,
            headers=headers,
            timeout=10
        )

        if response.status_code != 200:
            print("\n[!] Search .")
            return

        results = response.json()

        if not results:
            print("\n[!] Couldn't find place.")
            return

        best = results[0]
        address = best.get("address", {})

        house = address.get("house_number", "")
        road = address.get("road", "")
        city = (
            address.get("city")
            or address.get("town")
            or address.get("village")
            or address.get("municipality")
            or ""
        )
        province = address.get("state", "")
        country = address.get("country", "")

        street = " ".join(
            x for x in [house, road]
            if x
        )

        location = ", ".join(
            x for x in [city, province, country]
            if x
        )

        print(
            f"\n[+] {best.get('display_name', place).split(',')[0]}\n"
        )

        if street:
            print(f"Address: {street}")

        if location:
            print(f"Location: {location}")

    except:
        print("\n[!] Search Failed.")

def find_ip(ip):
    try:
        response = requests.get(
            f"https://ipwho.is/{ip}",
            timeout=10
        )

        data = response.json()

        if not data.get("success", True):
            print(f"[!] Lookup failed: {data.get('message', 'Unknown error')}")
            return

        ipinfo = {
            "IP: ": data.get("ip", "Unknown"),
            "IP Type: ": data.get("type", "Unknown"),
            "ISP: ": data.get("connection", {}).get("isp", "Unknown"),
            "Continent: ": data.get("continent", "Unknown"),
            "Country: ": data.get("country", "Unknown"),
            "State/Province: ": data.get("region", "Unknown"),
            "City: ": data.get("city", "Unknown")
        }

        for label, value in ipinfo.items():
            print(label + str(value))

    except requests.RequestException as e:
        print(f"[!] Request failed: {e}")

    except ValueError:
        print("[!] API returned invalid JSON.")
print_banner_black()

while True:
    user_input = input("> ")
    parts = shlex.split(user_input)

    if not parts:
        continue

    if parts[0].lower() == "findip":
        if len(parts) < 2:
            print("findip <ip>")
            continue

        find_ip(parts[1])
        continue

    if parts[0].lower() == "person":
        if len(parts) < 2:
            print('person "First Last"')
            continue

        name = " ".join(parts[1:])
        person_search(name)
        continue

    if parts[0].lower() == "place":
        if len(parts) < 2:
            print('place "Place Name"')
            continue

        place = " ".join(parts[1:])
        place_search(place)
        continue

    if parts[0].lower() == "myip":

        if len(parts) < 2:
            print("To get your IP you must specify the type")
            print("Usage: myip [-loc | -pub | -all]")
            continue

        if parts[1].lower() == "-loc":
            os.system("ipconfig getifaddr en0")
            continue

        if parts[1].lower() == "-pub":
            os.system("curl -4 -s ifconfig.me; echo")
            continue

        if parts[1].lower() == "-all":
            os.system("ifconfig")
            continue

        print("Unknown myip option")
        print("Usage: myip [-loc | -pub | -all]")
        continue

    if parts[0].lower() == "exit":
        break

    if parts[0].lower() == "pingsite":

        if len(parts) < 2:
            print("pingsite [URL]")
            continue

        web = parts[1]

        if not web.startswith(("http://", "https://")):
            web = "https://" + web
        pingsite(web)
        continue

    if parts[0].lower() == "webscan":
        if len(parts) < 2:
            print("webscan [URL]")
            continue

        dir_search(parts[1])
        continue

    if parts[0].lower() in ["cls", "clear"]:
        os.system("clear")
        print_banner_black()
        continue
    if parts[0].lower() == "sunrise":
        sunrise()
        continue

    if parts[0].lower() == "nightfall":
        nightfall()
        continue

    if parts[0].lower() == "linux":
            print("""
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠉⠀⠀⠀⠉⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⣰⣶⣤⣶⣆⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠀⠀⣼⣿⠉⠿⠉⣿⣧⠀⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⢀⣤⣶⣿⣿⣿⣶⣤⡀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠘⣧⠙⠿⠿⣿⣿⣿⠃⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠈⠉⣙⣛⣋⠉⠁⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⣿⣷⡄⠀⠀⠀⠀⠀⠙⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿
⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿
⣿⣿⣿⡟⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀⢻⣿⣿⣿
⣿⣿⣿⠁⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠈⣿⣿⣿
⣿⣿⡟⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⢻⣿⣿
⣿⣿⡇⠀⠀⣠⣆⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⣰⣄⠀⠀⢸⣿⣿
⣿⣿⡇⢀⣼⣿⣿⡄⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⢠⣿⣿⣧⡀⢸⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⠋⣠⣶⣶⣶⣶⣦⣤⣄⣉⣉⠙⠛⠋⣉⣉⣠⣤⣴⣶⣶⣶⣶⣄⠙⣿⣿⣿⣿
⣿⣿⣿⣿⢸⣿⣶⣭⣭⣛⣛⣛⣛⣛⣛⡛⠀⢛⣛⣛⣛⣛⣛⣛⣭⣭⣶⣿⡇⣿⣿⣿⣿
⣿⣿⣿⣿⣦⡈⠻⠿⣿⣿⣿⣿⣿⣿⠟⢁⣤⡈⠻⣿⣿⣿⣿⣿⣿⠿⠟⢁⣴⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣷⣶⣶⣶⣶⣶⣶⣶⣿⣿⣿⣶⣶⣶⣶⣶⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿

we couldn't afford linux so you can have this instead""")
            continue
    
    if parts[0].lower() == "ilovenightfall":
        ilove_nightfall()
        continue

    if parts[0].lower() == "helloworld(print)": 
        print("that's piton not python, are you okay?") 
        continue

    if parts[0].lower() == "iwantadmin": 
            print("no.") 
            continue
    

    if parts[0].lower() == "nightfall_ai": 
                print("we got a budget of like 5 cents, you think we can afford a nightfall ai?") 
                continue

    if parts[0].lower() == "update": 
                    print("why fix something thats not broken?") 
                    continue


    if parts[0].lower() == "about": 
                    print("nightfall, created when the night fell.") 
                    continue

    if parts[0].lower() == "debug": 
                        print("we couldnt afford a debug mode (we actually could were just lazy)") 
                        continue
    
    if parts[0].lower() == "help":
        print("you already have the custom command, be grateful")
        continue

    if parts[0].lower() == "theme":
        print("why dont you program it yourself, huh?")
        continue

    if parts[0].lower() == "hi":
            print("hey!")
            continue

    if len(parts) >= 2 and parts[0].lower() == "im" and parts[1].lower() == "lazy":
        print("the dev's are too.")
        continue

    if parts[0].lower() == "ihatenightfall":
        ihate_nightfall()
        continue

    if parts[0].lower() == "system":
        os.system("system_profiler SPSoftwareDataType SPHardwareDataType")
        continue

    if parts[0].lower() == "custom":
        custom()
        continue

    if parts[0].lower() == "vpn":
        os.system("open -a ProtonVPN")
        continue

    try:
        subprocess.run(user_input, shell=True)
    except Exception as e:
        print("Command Doesn't exist")